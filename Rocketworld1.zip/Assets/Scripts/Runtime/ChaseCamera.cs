using UnityEngine;

namespace RocketWorld
{
    /// <summary>Smoothed chase camera (port of RocketWorld's camera.js) with real collision against the tile colliders.</summary>
    [DefaultExecutionOrder(100)]
    public class ChaseCamera : MonoBehaviour
    {
        public RocketCar car;
        Vector3 _heading = Vector3.forward, _lookOffset;
        bool _ready;
        float _fov = 80f;
        Camera _cam;

        void Awake() { _cam = GetComponent<Camera>(); }
        void OnEnable() { _ready = false; }

        void LateUpdate()
        {
            if (car == null) return;
            float dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            var carPos = car.visual != null ? car.visual.position : car.transform.position;
            var carFwd = car.visual != null ? car.visual.forward : car.transform.forward;
            bool grounded = car.CurrentPhase == RocketCar.Phase.Running && (car.State.isOnGround || car.InBoat);   // a boat keeps the heading-follow camera

            var vel = car.UnityVelocity; var hv = new Vector3(vel.x, 0, vel.z);
            var dir = Vector3.ProjectOnPlane(carFwd, Vector3.up);
            if (!grounded && hv.magnitude > 6f) dir = hv;
            if (dir.sqrMagnitude < 1e-4f) dir = _heading;
            dir.Normalize();
            if (!_ready) _heading = dir;
            _heading = Vector3.Lerp(_heading, dir, 1f - Mathf.Exp(-dt * (grounded ? 3.6f : 2f))).normalized;

            float sp = Mathf.Clamp01(car.SpeedMS / 46f);   // (plane speeds exceed this: the clamp keeps the car-tuned FOV / distance bounded)
            bool plane = car.InPlane || car.InVehicle;                                      // the airplane is bigger and faster: sit further back and higher
            bool veh = car.InVehicle; var vs = veh ? car.vehicle.Spec : null;
            float back = veh ? vs.camBack : plane ? 17f : 7.6f + sp * 2.2f, upD = veh ? vs.camUp : plane ? 4.8f : 2.9f + sp * 0.5f, ahead = veh ? vs.camLook : plane ? 12f : 5f;
            var want = carPos - _heading * back; want.y = carPos.y + upD;   // pulls back a little with speed
            if (Physics.Linecast(carPos + Vector3.up * 0.8f, want, out var hit, PhysicsSetup.WorldMask, QueryTriggerInteraction.Ignore))
                want = hit.point + hit.normal * 0.4f;
            var tgt = carPos + _heading * ahead + Vector3.up;
            var pos = transform.position;                                  // camera has a CesiumGlobeAnchor: valid across origin shifts
            if (!_ready) { pos = want; _lookOffset = tgt - carPos; _ready = true; }
            pos = Vector3.Lerp(pos, want, 1f - Mathf.Exp(-dt * 6.5f));
            _lookOffset = Vector3.Lerp(_lookOffset, tgt - carPos, 1f - Mathf.Exp(-dt * 12f));
            if (Physics.Raycast(pos + Vector3.up * 50f, Vector3.down, out var gh, 60f, PhysicsSetup.TerrainMask, QueryTriggerInteraction.Ignore) && pos.y < gh.point.y + 0.8f)
                pos.y = gh.point.y + 0.8f;

            transform.SetPositionAndRotation(pos, Quaternion.LookRotation((carPos + _lookOffset) - pos, Vector3.up));
            float f = 72f + Mathf.SmoothStep(0f, 1f, Mathf.Min(car.SpeedMS / 46f, 1f)) * 16f + car.HyperT * 18f;   // Hyper Boost widens the view
            _fov += (f - _fov) * Mathf.Min(1f, dt * 2.5f);
            if (_cam != null) _cam.fieldOfView = _fov;
        }
    }
}
